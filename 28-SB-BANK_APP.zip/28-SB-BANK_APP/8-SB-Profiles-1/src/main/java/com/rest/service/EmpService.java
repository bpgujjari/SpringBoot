package com.rest.service;

import com.rest.entity.Employee;

public interface EmpService {
public Employee saveUser(Employee employee);
}
